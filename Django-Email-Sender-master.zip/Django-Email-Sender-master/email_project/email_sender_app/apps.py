from django.apps import AppConfig


class EmailProjConfig(AppConfig):
    name = 'email_sender_app'
